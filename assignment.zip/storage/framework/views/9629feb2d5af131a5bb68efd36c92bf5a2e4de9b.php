<?php $__env->startSection('title', 'Page Title'); ?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h3>Edit Details</h3>
        
        <div class="row">
                    <form action="/editSubmit" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($details->id); ?>">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Router SapID</label>
                            <input type="text" class="form-control" name="sapid" value="<?php echo e($details->sapid); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">RHost Name</label>
                            <input type="text" class="form-control" name="host_name"  value="<?php echo e($details->host_name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Loop Back</label>
                            <input type="text" class="form-control" name="loop_back"  value="<?php echo e($details->loop_back); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Mac Address</label>
                            <input type="text" class="form-control" name="mac_address" value="<?php echo e($details->mac_address); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
        </div>
        
    </div>
    
    

    


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assignment\resources\views/router/edit.blade.php ENDPATH**/ ?>